<?php

namespace Lic\VenteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LicVenteBundle extends Bundle
{
}
