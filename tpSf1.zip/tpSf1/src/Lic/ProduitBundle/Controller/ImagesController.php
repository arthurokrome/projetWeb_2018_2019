<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class ImagesController extends Controller
{

    public function listAction($numPage){
        $args=array(
            'numPage'=>$numPage,
            );
        return $this->render('@LicProduit/images/index.html.twig',$args);
    }


    public function viewAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/images/view.html.twig',$args);
    }


    public function createAction(){
        return $this->render('@LicProduit/images/create.html.twig');
    }


    public function updateAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/images/update.html.twig',$args);
    }


    public function deleteAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/images/delete.html.twig',$args);
    }
}
?>