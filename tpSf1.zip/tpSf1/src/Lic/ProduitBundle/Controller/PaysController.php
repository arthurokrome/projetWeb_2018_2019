<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class PaysController extends Controller
{

    public function listAction($numPage){
        $args=array(
            'numPage'=>$numPage,
            );
        return $this->render('@LicProduit/pays/index.html.twig',$args);
    }


    public function viewAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/pays/view.html.twig',$args);
    }


    public function createAction(){
        return $this->render('@LicProduit/pays/create.html.twig');
    }


    public function updateAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/pays/update.html.twig',$args);
    }


    public function deleteAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/pays/delete.html.twig',$args);
    }
}
?>