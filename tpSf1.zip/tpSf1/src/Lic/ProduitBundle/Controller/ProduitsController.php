<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class ProduitsController extends Controller
{

    public function listAction($numPage){
        $args=array(
            'numPage'=>$numPage,
            );
        return $this->render('@LicProduit/produits/index.html.twig',$args);
    }


    public function viewAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/produits/view.html.twig',$args);
    }


    public function createAction(){
        return $this->render('@LicProduit/produits/create.html.twig');
    }


    public function updateAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/produits/update.html.twig',$args);
    }


    public function deleteAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/produits/delete.html.twig',$args);
    }
}
?>