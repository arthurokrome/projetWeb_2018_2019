<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class MagasinsController extends Controller
{

    public function listAction($numPage){
        $args=array(
            'numPage'=>$numPage,
            );
        return $this->render('@LicProduit/magasins/index.html.twig',$args);
    }


    public function viewAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/magasins/view.html.twig',$args);
    }


    public function createAction(){
        return $this->render('@LicProduit/magasins/create.html.twig');
    }


    public function updateAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/magasins/update.html.twig',$args);
    }


    public function deleteAction($id){
        $args=array(
            'id'=>$id,
        );
        return $this->render('@LicProduit/magasins/delete.html.twig',$args);
    }
}
?>