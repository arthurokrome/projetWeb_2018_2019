<?php
/**
 * Created by PhpStorm.
 * User: amerig02
 * Date: 18/02/2019
 * Time: 14:48
 */
namespace Lic\SandboxBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;


class RoutesController extends Controller
{

    public function test1Action($year,$month,$filename,$ext){
        $args=array(
            'year'=> $year,
            'month'=> $month,
            'filename'=>$filename,
            'ext'=>$ext,
        );
        return $this->render('@LicSandbox/testroute/test1.html.twig',$args);
    }

    public function test4bisAction($year){
        $args=array(
            'year'=> $year,
        );
        return $this->render('@LicSandbox/testroute/test4bis.html.twig',$args);
    }
}
