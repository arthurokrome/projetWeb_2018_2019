<?php
/**
 * Created by PhpStorm.
 * User: amerig02
 * Date: 18/02/2019
 * Time: 14:48
 */
namespace Lic\SandboxBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class tp5Controller extends Controller
{
    public function indexAction(){
        $args = array(
        );
        return $this->render('@LicSandbox/tp5/vue1.html.twig',$args);
    }
    public function vue2Action(){
        $args = array(
        );
        return $this->render('@LicSandbox/tp5/vue2.html.twig',$args);
    }
    public function vue3Action(){
        $args = array(
        );
        return $this->render('@LicSandbox/tp5/vue3.html.twig',$args);
    }
    public function vue4Action(){
        $args = array(
        );
        return $this->render('@LicSandbox/tp5/vue4.html.twig',$args);
    }
    public function vue5Action(){
        $args = array(
        );
        return $this->render('@LicSandbox/tp5/vue5.html.twig',$args);
    }
    public function vue6Action(){
        $args = array(
            'nom'=>'Votre Nom',
            'email'=>'address@email.com',
                'tab' => array (
                    'mentions' => array(
                        'Info' => array(
                            'nom' => 'Informatique',
                            'parcours' => array(
                                'Informatique',
                                'Image',
                            ),
                            'responsable' => 'SJ',
                        ),
                        'PC' => array(
                            'nom' => 'Physique-Chimie',
                            'parcours' => array(
                                'Physique',
                                'Chimie minérale',
                            ),
                            'responsable' => 'GA',
                        ),
                        'Bio' => array(
                            'nom' => 'Biologie',
                            'parcours' => array(
                                'Géologie',
                                'Biologie végétale',
                                'Biologie animale',
                            ),
                            'responsable' => 'MN',
                        ),
                    ),
                    'ues' => array(
                        array(
                            'nom' => 'Algo 1',
                            'volume' => 54,
                        ),
                        array(
                            'nom' => 'Maths discrètes',
                            'volume' => 40,
                        ),
                        array(
                            'nom' => 'Anglais S1',
                            'volume' => 20,
                        ),
                        array(
                            'nom' => 'Anglais S2',
                            'volume' => 20,
                        ),
                        array(
                            'nom' => 'Projet',
                            'volume' => 70,
                        ),
                    ),
                )
        );
        return $this->render('@LicSandbox/tp5/vue6.html.twig',$args);
    }

}
