<?php
/**
 * Created by PhpStorm.
 * User: amerig02
 * Date: 18/02/2019
 * Time: 14:48
 */
namespace Lic\SandboxBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;


class MenuController extends Controller
{

    public function menuAction(){
        $args=array(
            'items'=>array(
            'Page1',
            'Page2',
            'Page3')
        );
        return $this->render('@LicSandbox/menu.html.twig',$args);
    }

}
