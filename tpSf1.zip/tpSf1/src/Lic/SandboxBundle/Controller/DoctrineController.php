<?php
/**
 * Created by PhpStorm.
 * User: amerig02
 * Date: 18/02/2019
 * Time: 14:48
 */
namespace Lic\SandboxBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Lic\SandboxBundle\Entity\Film;
use Lic\SandboxBundle\Entity\Critique;

class DoctrineController extends Controller
{
    public function listAction()
    {


        $em=$this->getDoctrine()->getEntityManager();
        $filmRepository=$em->getRepository('LicSandboxBundle:Film');

        $films=$filmRepository->findAll();

        $args = array(
            'films'=>$films,
        );

        return $this->render('@LicSandbox/Doctrine/list.html.twig',$args);
    }
    public function viewAction($id)
    {
        $em=$this->getDoctrine()->getEntityManager();
        $filmRepository=$em->getRepository('LicSandboxBundle:Film');
        $critiqueRepository=$em->getRepository('LicSandboxBundle:Critique');

        $film=$filmRepository->find($id);

        if($film===null)
            throw new NotFoundHttpException('Le film '.$id.' n\'existe pas;');

        $critiques=$critiqueRepository->findBy(array('film'=>$film));


        $args = array(
            'film'=>$film,
            'critiques'=>$critiques,

        );
        return $this->render('@LicSandbox/Doctrine/view.html.twig',$args);
    }
    public function deleteAction($id)
    {
        $em= $this->getDoctrine()->getEntityManager();
        $filmRepository=$em->getRepository('LicSandboxBundle:Film');

        $film=$filmRepository->find($id);
        $em->remove($film);
        $em->flush();

        dump($film);
        return $this->reDirectToRoute('lic_sandbox_doctrine_list',array());
    }

    public function addendurAction(){
        $em= $this->getDoctrine()->getEntityManager();

        $film = new Film();
        $film->setNom('Mr. Nobody');
        $film->setAnnee(2009);
        $film->setEnstock(true);
        $film->setPrix(9.99);
        $film->setQuantite(88);

        $em->persist($film);
        $em->flush();

        dump($film);
        return $this->reDirectToRoute('lic_sandbox_doctrine_view',array('id'=>$film->getId()));
    }

    public function modifieendurAction(){
        $em= $this->getDoctrine()->getEntityManager();
        $filmRepository=$em->getRepository('LicSandboxBundle:Film');

        $film=$filmRepository->find(15);

        $film->SetNom("The Nightmare Before Christmas");
        $film->setAnnee(1993);
        $em->flush();

        dump($film);
        return $this->reDirectToRoute('lic_sandbox_doctrine_view',array('id'=>$film->getId()));
    }

    public function effaceendurAction(){
        $em= $this->getDoctrine()->getEntityManager();
        $filmRepository=$em->getRepository('LicSandboxBundle:Film');

        $film=$filmRepository->find(16);
        $film=$filmRepository->find(16);
        $em->remove($film);
        $em->flush();

        dump($film);
        return $this->reDirectToRoute('lic_sandbox_doctrine_list',array());


    }

    public function addendurbisAction(){
        $film=new Film();
        $film->setNom('Le grand bleu');
        $film->setAnnee(1988);
        $film->setEnstock(true);
        $film->setPrix(9.99);
        $film->setQuantite(88);

        $critique1=new Critique();
        $critique1->SetNote(5);
        $critique1->setAvis('ça a changé toute ma vie');
        $critique1->setFilm($film);

        $critique2=new Critique();
        $critique2->SetNote(0);
        $critique2->setAvis('le grand vide plutôt !');
        $critique2->setFilm($film);

        $em=$this->getDoctrine()->getEntityManager();
        $em->persist($film);
        $em->persist($critique1);
        $em->persist($critique2);
        $em->flush();

        dump($film);
        return $this->reDirectToRoute('lic_sandbox_doctrine_view',array('id'=>$film->getId()));

    }

}
