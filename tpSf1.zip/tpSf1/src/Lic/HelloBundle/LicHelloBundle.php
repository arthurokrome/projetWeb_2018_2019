<?php

namespace Lic\HelloBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LicHelloBundle extends Bundle
{
}
